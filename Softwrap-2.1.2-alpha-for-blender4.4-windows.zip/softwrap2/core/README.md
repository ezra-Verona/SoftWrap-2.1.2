# Softwrap 2 - Blender 4.4 Compatibility Fix

This is a modified version of the **Softwrap 2** Blender addon that has been patched to work with **Blender 4.4**.

## What Was Done

I made changes to get the addon running with Blender 4.4, including:
- Recompiling the core Cython module (`softwrap_core2`) for Python 3.11 (Blender 4.4's version).
- Cleaning up the addon folder so it only contains what’s needed to use it or modify it.
- Keeping the `core` folder so developers can modify and recompile the Cython code if needed.

## Important Notes

- I have minimal knowledge of how all of this works — I mostly followed trial and error, tips from the internet, and help from ChatGPT.
- If anything breaks or needs fixing, I **highly recommend asking ChatGPT** with a clear description of the problem. It helped a lot in getting this working!

## Included Files

- `__init__.py`, `draw_3d.py`, `softwrap_core2.pyd`: These are essential to running the addon.
- `core/`: Contains optional source files (`core2.pyx`, `setup.py`) for anyone who wants to recompile or make changes.
- `python311.dll`: Required by the compiled `.pyd` file for Blender compatibility.

## Recompiling (For Developers)

If you want to modify the Cython source and rebuild `softwrap_core2.pyd`, you’ll need:
- Python 3.11 installed (to match Blender 4.4).
- Cython and a working C++ compiler (e.g., Visual Studio Build Tools).
- Run the following in the `core/` directory:

```bash
python setup.py build_ext --inplace
```

Make sure the correct Python version and environment is being used when building.

---

Feel free to tweak or improve this. I hope it helps!
